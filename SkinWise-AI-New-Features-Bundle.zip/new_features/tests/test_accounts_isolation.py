import sqlite3
import pytest
from auth import AuthError, authenticate, register
from storage import (add_journal_entry, clear_all_user_data, delete_account, get_checkins, get_journal_entries, get_scans,
                     save_checkins, save_scan, connect)

FAST = 1000  # PBKDF2 iterations for fast tests


def test_register_login_and_wrong_password(tmp_path):
    db = tmp_path / "a.db"
    uid = register("Asha_K", "correct horse", db, iterations=FAST)
    assert uid == "user:asha_k"
    assert authenticate("asha_k", "correct horse", db) == uid
    with pytest.raises(AuthError):
        authenticate("asha_k", "wrong password", db)
    with pytest.raises(AuthError):
        authenticate("nobody", "whatever1", db)


def test_password_is_not_stored_in_plaintext(tmp_path):
    db = tmp_path / "a.db"
    register("asha", "s3cretpassword", db, iterations=FAST)
    with connect(db) as conn:
        row = conn.execute("SELECT * FROM users").fetchone()
    assert "s3cretpassword" not in " ".join(str(v) for v in tuple(row))


def test_validation_and_duplicates(tmp_path):
    db = tmp_path / "a.db"
    with pytest.raises(AuthError):
        register("a", "longenough", db, iterations=FAST)
    with pytest.raises(AuthError):
        register("valid_name", "short", db, iterations=FAST)
    register("valid_name", "longenough", db, iterations=FAST)
    with pytest.raises(AuthError):
        register("VALID_NAME", "longenough", db, iterations=FAST)


def test_lockout_after_repeated_failures(tmp_path):
    db = tmp_path / "a.db"
    register("asha", "correct horse", db, iterations=FAST)
    for _ in range(5):
        with pytest.raises(AuthError):
            authenticate("asha", "bad", db, now=1000)
    with pytest.raises(AuthError) as e:
        authenticate("asha", "correct horse", db, now=1001)      # correct password, but locked
    assert "Too many" in str(e.value)
    assert authenticate("asha", "correct horse", db, now=1000 + 301) == "user:asha"


def test_users_cannot_see_each_others_data(tmp_path):
    db = tmp_path / "a.db"
    save_scan({"date": "2026-10-26", "concerns": ["A"]}, db, user_id="user:a")
    save_scan({"date": "2026-10-26", "concerns": ["B"]}, db, user_id="user:b")
    add_journal_entry({"date": "2026-10-26", "note": "private"}, db, user_id="user:a")
    save_checkins("2026-10-26", ["x"], ["x"], db, user_id="user:a")
    assert get_scans(db, user_id="user:a")[0]["concerns"] == ["A"]
    assert get_scans(db, user_id="user:b")[0]["concerns"] == ["B"]
    assert get_journal_entries(db, user_id="user:b") == []
    assert get_checkins(db, user_id="user:b") == []


def test_delete_only_affects_that_user(tmp_path):
    db = tmp_path / "a.db"
    save_scan({"date": "d"}, db, user_id="user:a")
    save_scan({"date": "d"}, db, user_id="user:b")
    clear_all_user_data(db, user_id="user:a")
    assert get_scans(db, user_id="user:a") == [] and len(get_scans(db, user_id="user:b")) == 1


def test_delete_account_removes_login_and_data(tmp_path):
    db = tmp_path / "a.db"
    register("asha", "correct horse", db, iterations=FAST)
    save_scan({"date": "d"}, db, user_id="user:asha")
    delete_account("asha", db)
    assert get_scans(db, user_id="user:asha") == []
    with pytest.raises(AuthError):
        authenticate("asha", "correct horse", db)


def test_old_single_user_database_is_migrated_not_lost(tmp_path):
    db = tmp_path / "old.db"
    conn = sqlite3.connect(db)
    conn.executescript("""
    CREATE TABLE journal (id INTEGER PRIMARY KEY AUTOINCREMENT, entry_date TEXT NOT NULL, source TEXT NOT NULL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE routine_checkins (id INTEGER PRIMARY KEY AUTOINCREMENT, checkin_date TEXT NOT NULL, step_name TEXT NOT NULL, completed INTEGER NOT NULL CHECK (completed IN (0,1)), UNIQUE(checkin_date, step_name));
    CREATE TABLE scans (id INTEGER PRIMARY KEY AUTOINCREMENT, scan_date TEXT NOT NULL, source TEXT NOT NULL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE routines (id INTEGER PRIMARY KEY AUTOINCREMENT, saved_date TEXT NOT NULL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    INSERT INTO journal(entry_date, source, payload_json) VALUES ('2026-10-01','Journal entry','{"date":"2026-10-01","note":"old"}');
    INSERT INTO routine_checkins(checkin_date, step_name, completed) VALUES ('2026-10-01','Cleanser',1);
    INSERT INTO scans(scan_date, source, payload_json) VALUES ('2026-10-01','Live','{"date":"2026-10-01"}');
    """)
    conn.commit(); conn.close()
    assert get_journal_entries(db)[0]["note"] == "old"
    assert get_checkins(db)[0]["step_name"] == "Cleanser"
    assert len(get_scans(db)) == 1
    save_checkins("2026-10-01", [], ["Cleanser"], db)       # upsert works on the rebuilt table
    assert get_checkins(db)[0]["completed"] == 0
