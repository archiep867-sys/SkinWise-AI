from revision import active_ops, apply_ops, revise_from_scans, run_adaptive_loop, scan_key
from skincare import build_routine
from storage import get_revisions, set_revision_status


def scan(task, **raw):
    return {"task_id": task, "date": "2026-10-26", "metrics": [{"label": k.replace("_", " ").title(), "value": v, "raw_score": v} for k, v in raw.items()]}


def base_plan(sens="Low", style="Balanced (one optional extra)"):
    return build_routine({}, "₹500–₹1,000", "Oily", ["Acne / breakouts"], sens, style)


def test_drop_in_redness_score_simplifies_routine():
    prev, cur = scan("a", redness=80), scan("b", redness=60)
    rev = revise_from_scans(prev, cur, "Low", [])
    assert rev["outcome"] == "revised" and rev["changes"][0]["metric"] == "Redness"
    plan = apply_ops(base_plan(), rev["ops"])
    names = [s["name"] for s in plan["morning"] + plan["evening"]]
    assert not any(n.lower().startswith("optional") for n in names)
    assert "Barrier-supporting moisturizer" in names
    assert any("Pause exfoliating" in h for h in plan["holds"])


def test_a_RISE_in_redness_score_is_not_treated_as_a_problem():
    # YouCam: higher = healthier. This was inverted in the first version of the app.
    rev = revise_from_scans(scan("a", redness=60), scan("b", redness=80), "Low", [])
    assert rev["outcome"] == "unchanged" and not rev["ops"]
    assert any("improved" in k for k in rev["kept"])


def test_small_changes_are_ignored_as_noise():
    assert revise_from_scans(scan("a", redness=70), scan("b", redness=67), "Low", [])["outcome"] == "unchanged"


def test_moisture_drop_makes_morning_gentler_and_holds_acids():
    rev = revise_from_scans(scan("a", moisture=70), scan("b", moisture=55), "Low", [])
    plan = apply_ops(base_plan(), rev["ops"])
    assert plan["morning"][0]["name"] == "Gentle rinse or cleanser"
    assert any("exfoliating" in h.lower() for h in plan["holds"])


def test_spots_drop_adds_sunscreen_reapply_step_and_renumbers():
    rev = revise_from_scans(scan("a", age_spot=80), scan("b", age_spot=70), "Low", [])
    plan = apply_ops(base_plan(), rev["ops"])
    assert plan["morning"][-1]["name"] == "Reapply sunscreen if outdoors"
    assert [s["step"] for s in plan["morning"]] == list(range(1, len(plan["morning"]) + 1))


def test_sharp_fall_escalates_to_dermatologist():
    rev = revise_from_scans(scan("a", acne=85), scan("b", acne=60), "Low", [])
    assert rev["escalate"] is True
    assert any("dermatologist" in o.get("text", "") for o in rev["ops"] if o["op"] == "note")


def test_revisions_never_add_actives():
    rev = revise_from_scans(scan("a", redness=90, acne=90, moisture=90, oiliness=90), scan("b", redness=50, acne=50, moisture=50, oiliness=50), "Low", [])
    before = base_plan()
    after = apply_ops(before, rev["ops"])
    new_names = {s["name"].lower() for s in after["morning"] + after["evening"]} - {s["name"].lower() for s in before["morning"] + before["evening"]}
    assert all(not any(w in n for w in ("retinol", "acid", "serum", "vitamin c", "benzoyl")) for n in new_names)


def test_apply_ops_is_idempotent_and_does_not_mutate_input():
    rev = revise_from_scans(scan("a", redness=80), scan("b", redness=60), "Low", [])
    plan = base_plan(); snapshot = str(plan)
    once = apply_ops(plan, rev["ops"]); twice = apply_ops(once, rev["ops"])
    assert str(plan) == snapshot and once == twice


def test_needs_two_scans():
    assert revise_from_scans(None, scan("b", redness=60))["outcome"] == "needs_two_scans"


def test_loop_runs_once_per_scan_and_can_be_reverted(tmp_path):
    db = tmp_path / "r.db"
    live = [scan("new", redness=55), scan("old", redness=80)]
    assert run_adaptive_loop(live[:1], "u", "Low", [], db) is None
    first = run_adaptive_loop(live, "u", "Low", [], db)
    assert first and first["outcome"] == "revised"
    assert run_adaptive_loop(live, "u", "Low", [], db) is None            # same scan again: no duplicate
    revs = get_revisions(db, user_id="u")
    assert len(revs) == 1 and revs[0]["status"] == "applied" and active_ops(revs)
    set_revision_status(revs[0]["id"], "reverted", db, user_id="u")
    assert active_ops(get_revisions(db, user_id="u")) == []               # reverted -> base routine again
    assert get_revisions(db, user_id="someone-else") == []


def test_high_sensitivity_profile_gets_minimal_routine():
    rev = revise_from_scans(scan("a", moisture=80), scan("b", moisture=60), "High", [])
    plan = apply_ops(base_plan("High"), rev["ops"])
    assert any("high-sensitivity" in n for n in plan["revision_notes"])
