"""Dermatologist hand-off: consult *requests*, clinician summary, urgent-symptom screening.

SkinWise cannot book appointments or run live consultations (that needs a licensed clinical partner and
integration with a provider's scheduling system). What it does instead:
  1. screens for symptoms that need urgent in-person care rather than an app,
  2. builds a concise, factual summary the person can hand to a clinician,
  3. saves a consult request (preferred mode / city / timing) and offers a ready-to-send email draft,
  4. links to established teleconsultation directories.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote

URGENT_FLAGS = {
    "A mole or spot that is changing in size, shape or colour, bleeding or crusting": "possible skin-cancer warning sign",
    "Swelling of the face, lips or tongue, or trouble breathing": "possible severe allergic reaction",
    "Rapidly spreading redness, pain, warmth, pus or fever": "possible skin infection",
    "Blistering or peeling skin after starting a product or medicine": "possible severe reaction",
}
URGENT_MESSAGE = ("Based on what you selected, please seek in-person medical care promptly (a doctor, urgent care or emergency "
                  "services if you have trouble breathing). Do not wait for an online appointment, and do not rely on this app.")

TELECONSULT_DIRECTORIES = [
    {"name": "eSanjeevani (Govt. of India teleconsultation)", "url": "https://esanjeevaniopd.in/"},
    {"name": "Practo", "url": "https://www.practo.com/"},
    {"name": "Apollo 24|7", "url": "https://www.apollo247.com/"},
]
DIRECTORY_NOTE = "Third-party services; SkinWise has no relationship with them. Check availability, fees and the clinician's credentials yourself."

REASONS = ["Persistent or worsening acne", "Redness / irritation that is not settling", "Dark spots or pigmentation",
           "Dryness / eczema-like symptoms", "A reaction to a product", "General skin check", "Other"]


def urgent_screen(selected_flags: list[str]) -> dict[str, Any]:
    flags = [f for f in selected_flags if f in URGENT_FLAGS]
    return {"urgent": bool(flags), "flags": flags, "message": URGENT_MESSAGE if flags else ""}


def _metric_line(m: dict[str, Any]) -> str:
    ui, raw = m.get("ui_score"), m.get("raw_score")
    extra = f"UI {ui:g}" if isinstance(ui, (int, float)) else ""
    extra += (", " if extra and isinstance(raw, (int, float)) else "") + (f"raw {raw:g}" if isinstance(raw, (int, float)) else "")
    return f"- {m.get('label')}: {m.get('value')} ({extra})" if extra else f"- {m.get('label')}: {m.get('value')}"


def build_clinician_summary(profile: dict[str, Any], scans: list[dict[str, Any]], routine: dict[str, Any] | None,
                            journal: list[dict[str, Any]], revisions: list[dict[str, Any]], reason: str = "",
                            patient_note: str = "") -> str:
    """Plain-text summary. Contains only what the person has entered plus app-generated scan scores."""
    lines = ["SKINWISE AI - PATIENT-PREPARED SUMMARY",
             "Prepared by the patient using a consumer app. Not a clinical record or a diagnosis.", ""]
    if reason:
        lines += [f"Reason for visit: {reason}"]
    if patient_note.strip():
        lines += [f"Patient note: {patient_note.strip()[:1000]}"]
    lines += ["", "PROFILE (self-reported)",
              f"- Skin type: {profile.get('skin_type', 'n/a')}", f"- Concerns: {', '.join(profile.get('concerns', [])) or 'n/a'}",
              f"- Sensitivity: {profile.get('sensitivity', 'n/a')}", f"- Ingredients to avoid / known triggers: {', '.join(profile.get('avoid', [])) or 'none listed'}"]
    live = [s for s in scans if "Live YouCam" in str(s.get("source", "")) and s.get("metrics")]
    if live:
        latest = live[0]
        lines += ["", f"LATEST AI PHOTO SCAN ({latest.get('date')}) - YouCam Skin Analysis; higher = healthier-looking; photo-based estimate only"]
        lines += [_metric_line(m) for m in latest["metrics"] if isinstance(m.get("value"), (int, float))]
        if len(live) >= 2:
            from differentiators import compare_scans
            lines += ["", f"CHANGE SINCE PREVIOUS SCAN ({live[1].get('date')} -> {latest.get('date')}), raw-score points"]
            lines += [f"- {r['concern']}: {r['delta']:+g} ({r['trend']})" for r in compare_scans(live[1], latest)]
    else:
        lines += ["", "No live AI scan on record."]
    if routine:
        lines += ["", "CURRENT ROUTINE"]
        for period in ("morning", "evening"):
            lines.append(f"{period.title()}: " + "; ".join(s["name"] for s in routine.get(period, [])))
        for hold in routine.get("holds", []):
            lines.append(f"- On hold: {hold}")
    applied = [r for r in revisions if r.get("status") == "applied" and r.get("changes")]
    if applied:
        lines += ["", "AUTOMATIC ROUTINE REVISIONS (rule-based, app-generated)"]
        lines += [f"- {c['metric']}: {c['action']}" for c in applied[0]["changes"]]
    if journal:
        lines += ["", "RECENT JOURNAL (newest first)"]
        for entry in journal[:5]:
            lines.append(f"- {entry.get('date')}: feel={entry.get('skin_feel', 'n/a')}, routine days/week={entry.get('adherence_days', 'n/a')}"
                         + (f", note: {str(entry.get('note', ''))[:140]}" if entry.get("note") else ""))
    lines += ["", "Limitations: scores come from a consumer photo analysis and are affected by lighting, camera and makeup."]
    return "\n".join(lines)


def build_consult_request(*, mode: str, city: str, reason: str, timing: str, contact_note: str, summary_included: bool) -> dict[str, Any]:
    if mode not in {"In-person", "Teleconsultation"}:
        raise ValueError("mode must be 'In-person' or 'Teleconsultation'")
    return {"mode": mode, "city": city.strip()[:80], "reason": reason, "timing": timing.strip()[:120],
            "contact_note": contact_note.strip()[:300], "summary_included": bool(summary_included),
            "status": "saved - not sent. SkinWise does not book appointments."}


def mailto_link(to: str, request: dict[str, Any], summary: str) -> str:
    """mailto: link (clients truncate very long bodies, so the summary is cut to a safe length)."""
    subject = f"Appointment request - {request['reason']}"
    body = (f"Hello,\n\nI would like to request a {request['mode'].lower()} appointment"
            + (f" in {request['city']}" if request.get("city") else "") + f". Preferred timing: {request.get('timing') or 'flexible'}.\n\n"
            + summary[:1200] + "\n\nThank you.")
    return f"mailto:{quote(to)}?subject={quote(subject)}&body={quote(body)}"
