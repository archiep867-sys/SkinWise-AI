"""Adaptive routine revision: the app's closed loop from new scan -> evidence -> revised routine.

When a new real scan is saved, ``revise_from_scans`` compares it to the previous real scan and emits a list of
*operations* (rename a step, drop an optional active, add a sunscreen reapply step, hold exfoliants...). The
operations are stored and re-applied to whatever base routine the profile generates, so the revision stays in
effect and can be reverted by the user at any time.

Safety design: revisions only ever SIMPLIFY or soften a routine. They never add actives, never diagnose, and
escalate to "see a dermatologist" when scores fall sharply. Direction follows the YouCam docs: a higher score
means healthier-looking skin, so a DROP is the signal to react to.
"""
from __future__ import annotations

import copy
from typing import Any

from differentiators import NOISE_BAND, compare_scans

ESCALATE_DROP = 15.0           # a single metric falling this far triggers the dermatologist prompt
ESCALATE_MULTI = 3             # ...or this many tracked metrics each falling past the noise band


def _renumber(steps: list[dict[str, Any]]) -> None:
    for i, step in enumerate(steps, 1):
        step["step"] = i


def apply_ops(plan: dict[str, Any], ops: list[dict[str, Any]]) -> dict[str, Any]:
    """Return a copy of ``plan`` with the stored operations applied (idempotent)."""
    out = copy.deepcopy(plan)
    out.setdefault("holds", [])
    out.setdefault("revision_notes", [])
    for op in ops:
        kind = op.get("op")
        if kind == "rename":
            for period in ("morning", "evening"):
                for step in out[period]:
                    if op["match"].lower() in step["name"].lower() and step["name"] != op["to"]:
                        step["name"] = op["to"]
                        step["why"] = op.get("why", step["why"])
        elif kind == "remove_optional":
            for period in ("morning", "evening"):
                out[period] = [s for s in out[period] if not s["name"].lower().startswith("optional")]
        elif kind == "add_step":
            steps = out[op["period"]]
            if not any(s["name"] == op["name"] for s in steps):
                steps.append({"step": len(steps) + 1, "name": op["name"], "why": op["why"]})
        elif kind == "hold" and op["text"] not in out["holds"]:
            out["holds"].append(op["text"])
        elif kind == "note" and op["text"] not in out["revision_notes"]:
            out["revision_notes"].append(op["text"])
    for period in ("morning", "evening"):
        _renumber(out[period])
    return out


def revise_from_scans(previous: dict[str, Any] | None, current: dict[str, Any] | None,
                      sensitivity: str = "Not sure", avoid: list[str] | None = None,
                      band: float = NOISE_BAND) -> dict[str, Any]:
    """Compute a revision (ops + human-readable changes) from two real scans. Never raises on odd input."""
    if not previous or not current:
        return {"outcome": "needs_two_scans", "ops": [], "changes": [], "escalate": False, "kept": []}
    rows = compare_scans(previous, current)
    ops: list[dict[str, Any]] = []
    changes: list[dict[str, Any]] = []
    kept: list[str] = []
    declined = [r for r in rows if r["delta"] <= -band and r["concern"] != "Overall score"]

    def record(row: dict[str, Any], action: str, reason: str) -> None:
        changes.append({"metric": row["concern"], "delta": row["delta"], "action": action, "reason": reason})

    for row in declined:
        label = row["concern"].lower()
        d = f"{abs(row['delta']):g}"
        if "redness" in label:
            ops += [{"op": "remove_optional"},
                    {"op": "rename", "match": "moisturizer", "to": "Barrier-supporting moisturizer",
                     "why": "Redness score dropped; use a simple fragrance-free barrier cream and keep actives paused."},
                    {"op": "hold", "text": "Pause exfoliating acids and retinoids for about 2 weeks, then reintroduce one at a time."}]
            record(row, "Dropped optional actives; switched to a barrier-supporting moisturizer; paused exfoliants", f"Redness score fell {d} points.")
        elif "acne" in label:
            ops += [{"op": "remove_optional"},
                    {"op": "hold", "text": "Do not add new actives while breakouts are worsening; keep cleansing gentle and avoid picking."},
                    {"op": "note", "text": "If breakouts keep worsening for 4+ weeks, or are painful/scarring, see a dermatologist."}]
            record(row, "Removed optional acne product; no new actives; added dermatologist guidance", f"Acne score fell {d} points.")
        elif any(t in label for t in ("moisture", "hydration")):
            ops += [{"op": "rename", "match": "moisturizer", "to": "Barrier-supporting moisturizer",
                     "why": "Moisture score dropped; use a richer, fragrance-free moisturizer."},
                    {"op": "rename", "match": "gentle cleanser", "to": "Gentle rinse or cleanser",
                     "why": "Moisture score dropped; rinse with water in the morning if skin feels tight."},
                    {"op": "hold", "text": "Hold exfoliating acids until skin feels comfortable again."}]
            record(row, "Richer moisturizer; gentler morning cleanse; exfoliants on hold", f"Moisture score fell {d} points.")
        elif "oil" in label:
            ops.append({"op": "rename", "match": "moisturizer", "to": "Light gel-type moisturizer",
                        "why": "Oiliness score dropped; a lighter, non-greasy texture may feel better."})
            record(row, "Switched to a lighter gel-type moisturizer", f"Oiliness score fell {d} points.")
        elif any(t in label for t in ("spot", "pigment")):
            ops.append({"op": "add_step", "period": "morning", "name": "Reapply sunscreen if outdoors",
                        "why": "Spots/pigmentation score dropped; consistent sun protection helps stop dark spots worsening."})
            record(row, "Added a sunscreen reapplication step", f"Spots score fell {d} points.")
        elif any(t in label for t in ("wrinkle", "firm", "texture", "radiance", "pore", "dark circle", "eye bag")):
            ops.append({"op": "note", "text": f"{row['concern']} score fell {d} points; this usually moves slowly. Re-scan in similar light before changing anything."})
            record(row, "No product change; note added", f"{row['concern']} fell {d} points but is slow-moving and photo-sensitive.")
    for row in rows:
        if row["delta"] >= band and row["concern"] != "Overall score":
            kept.append(f"{row['concern']} improved by {row['delta']:g}; keep what you are doing.")

    # Safety floor: high sensitivity profiles only ever get simpler.
    if sensitivity == "High" or "Known personal trigger (unspecified)" in (avoid or []):
        if declined:
            ops.append({"op": "remove_optional"})
            ops.append({"op": "note", "text": "Your profile is high-sensitivity, so the routine was kept minimal."})

    escalate = any(r["delta"] <= -ESCALATE_DROP for r in declined) or len(declined) >= ESCALATE_MULTI
    if escalate:
        ops.append({"op": "note", "text": "Scores fell sharply. Consider booking a dermatologist visit; do not rely on this app to explain why."})
    outcome = "revised" if (ops or changes) else "unchanged"
    return {"outcome": outcome, "ops": ops, "changes": changes, "kept": kept, "escalate": escalate,
            "disclaimer": "Automatic revisions are conservative rules, not proof that any product caused a score change. Lighting, angle and makeup move scores too. You can revert at any time."}


def scan_key(scan: dict[str, Any]) -> str:
    return str(scan.get("task_id") or f"{scan.get('date', '')}-{len(scan.get('metrics', []))}")


def run_adaptive_loop(live_scans: list[dict[str, Any]], user_id: str, sensitivity: str, avoid: list[str],
                      db_path=None) -> dict[str, Any] | None:
    """Call after saving a new live scan (``live_scans`` is newest-first). Creates and stores a revision once per scan."""
    from storage import revision_exists, save_revision
    if len(live_scans) < 2:
        return None
    current, previous = live_scans[0], live_scans[1]
    key = scan_key(current)
    if revision_exists(key, db_path, user_id=user_id):
        return None
    revision = revise_from_scans(previous, current, sensitivity, avoid)
    revision.update({"from_scan": scan_key(previous), "to_scan": key, "to_date": current.get("date")})
    save_revision(key, revision, db_path, user_id=user_id)
    return revision


def active_ops(revisions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Operations from the most recent *applied* revision that has changes (older ones are superseded)."""
    for rev in revisions:           # newest first
        if rev.get("status") == "applied" and rev.get("ops"):
            return rev["ops"]
    return []
