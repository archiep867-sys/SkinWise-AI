"""Measured progress report: score changes between real scans next to routine adherence.

What this IS: a transparent summary of how YouCam's photo-based scores moved between two scans and how consistently
the routine was followed in that window. What it is NOT: proof that the routine caused any change. One person,
two photos, uncontrolled lighting - differences inside the noise band are reported as "within noise".
"""
from __future__ import annotations

from datetime import date
from typing import Any

from differentiators import NOISE_BAND, compare_scans


def _parse(d: str | None) -> date | None:
    try:
        return date.fromisoformat(str(d)[:10])
    except (TypeError, ValueError):
        return None


def adherence_between(checkins: list[dict[str, Any]], start: str | None, end: str | None) -> dict[str, Any]:
    a, b = _parse(start), _parse(end)
    days: dict[str, list[int]] = {}
    for row in checkins:
        d = _parse(row.get("checkin_date"))
        if d and (a is None or d >= a) and (b is None or d <= b):
            days.setdefault(str(d), []).append(int(row.get("completed", 0)))
    if not days:
        return {"days_logged": 0, "avg_completion_pct": None}
    per_day = [sum(v) / len(v) for v in days.values()]
    return {"days_logged": len(days), "avg_completion_pct": round(100 * sum(per_day) / len(per_day), 1)}


def progress_report(live_scans: list[dict[str, Any]], checkins: list[dict[str, Any]], band: float = NOISE_BAND) -> dict[str, Any]:
    """``live_scans`` newest first. Compares the oldest and newest real scans."""
    if len(live_scans) < 2:
        return {"available": False, "reason": "Complete at least two real scans to see measured progress."}
    first, last = live_scans[-1], live_scans[0]
    rows = compare_scans(first, last)
    overall = next((r for r in rows if r["concern"] == "Overall score"), None)
    metric_rows = [r for r in rows if r["concern"] != "Overall score"]
    adherence = adherence_between(checkins, first.get("date"), last.get("date"))
    d1, d2 = _parse(first.get("date")), _parse(last.get("date"))
    days = (d2 - d1).days if d1 and d2 else None
    improved = [r for r in metric_rows if r["trend"] == "improved"]
    declined = [r for r in metric_rows if r["trend"] == "declined"]
    steady = [r for r in metric_rows if r["trend"] == "within noise"]
    notes = [f"Changes smaller than {band:g} points are treated as photo-to-photo noise (a conservative heuristic, not a validated error bar).",
             "This shows how scores moved; it does not show that your routine caused the change."]
    if days is not None and days < 14:
        notes.append("These scans are less than two weeks apart; skin changes are usually slower than that.")
    if adherence["avg_completion_pct"] is not None and adherence["avg_completion_pct"] < 50:
        notes.append("Routine check-ins were logged on fewer than half of the steps, so the comparison says little about the routine.")
    if adherence["days_logged"] == 0:
        notes.append("No routine check-ins were saved between these scans, so adherence is unknown.")
    return {"available": True, "from_date": first.get("date"), "to_date": last.get("date"), "days_between": days,
            "overall": overall, "improved": improved, "declined": declined, "steady": steady,
            "adherence": adherence, "notes": notes, "n_scans": len(live_scans)}


def report_text(report: dict[str, Any]) -> str:
    if not report.get("available"):
        return report.get("reason", "No report available.")
    lines = [f"SkinWise progress report: {report['from_date']} -> {report['to_date']} ({report['days_between']} days)", ""]
    if report["overall"]:
        o = report["overall"]
        lines.append(f"Overall score: {o['baseline']:g} -> {o['followup']:g} ({o['delta']:+g}, {o['trend']})")
    for label, key in (("Improved", "improved"), ("Declined", "declined"), ("Within noise", "steady")):
        rows = report[key]
        if rows:
            lines.append(f"{label}: " + ", ".join(f"{r['concern']} {r['delta']:+g}" for r in rows))
    a = report["adherence"]
    lines.append(f"Routine check-ins: {a['days_logged']} day(s) logged, average completion "
                 + (f"{a['avg_completion_pct']}%" if a["avg_completion_pct"] is not None else "n/a"))
    lines += [""] + report["notes"]
    return "\n".join(lines)
