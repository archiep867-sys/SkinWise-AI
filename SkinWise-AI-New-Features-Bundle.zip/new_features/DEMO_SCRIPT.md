# Demo video script (target 2:40, hard limit 3:00)

Record on the device you built for (browser). Show the real app, real API results. Say the YouCam API names out loud and keep them visible on screen. No copyrighted music.

Before recording: create an account, have two real scans already saved from different days (or do a second scan on camera if time allows), add 2-3 verified products.

| Time | Show | Say |
|---|---|---|
| 0:00-0:15 | Home page | "People buy skincare before they know what their skin needs, then never find out if it worked. SkinWise closes that loop with YouCam Skin AI." |
| 0:15-0:50 | Upload selfie → Analyze. Show spinner, then results. Point at *Lowest-scoring areas*, overall score, skin age | "This calls YouCam Skin Analysis v2.1: file upload, task, polling. Scores run 1-100, higher is healthier, so these are my lowest areas." |
| 0:50-1:15 | My routine tab: routine, patch-test reminder | "The routine respects my sensitivity and exclusions. Nothing is added just because a score is low." |
| 1:15-1:50 | Revision panel (second scan already saved): show change list, the 'On hold' warning, Revert button | "After a re-scan, my redness score dropped 22 points, so the app automatically simplified my routine and paused exfoliants. It can only soften, never add actives, and I can revert." |
| 1:50-2:10 | Progress report + trend | "Measured progress compares raw scores and shows my routine adherence. Small changes are labelled noise, not wins." |
| 2:10-2:30 | Product match → budget optimiser → add to cart → shopping list | "A shortlist inside my budget with cheaper swaps, and a per-retailer list." |
| 2:30-2:50 | Look preview: render a look | "And YouCam AI Makeup Virtual Try-On previews a look on my photo." |
| 2:50-3:00 | Dermatologist tab | "Anything urgent goes to a real clinician; SkinWise prepares the summary. Not medical advice." |

Do not claim: clinical accuracy, that the routine caused a change, real-time prices, booking, or purchases inside the app.
