"""Headless UI tests using Streamlit's AppTest: the real app script is executed and clicked through."""
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

import auth, cart, storage
from revision import run_adaptive_loop


@pytest.fixture()
def db(tmp_path, monkeypatch):
    monkeypatch.setattr(storage, "DEFAULT_DB", tmp_path / "ui.db")
    monkeypatch.delenv("SKINWISE_SINGLE_USER", raising=False)
    return tmp_path / "ui.db"


def _scan(t, d, **raw):
    return {"task_id": t, "date": d, "source": "Live YouCam Skin Analysis v2.1", "concerns": [],
            "metrics": [{"label": k.title(), "value": v, "raw_score": v, "ui_score": v} for k, v in raw.items()]}


def _app(uid=None, name=None):
    at = AppTest.from_file(str(Path(__file__).resolve().parent.parent / "app.py"), default_timeout=60)
    if uid:
        at.session_state["user_id"], at.session_state["username"] = uid, name
    return at


def _click(at, label):
    next(b for b in at.button if b.label == label).click()
    at.run()


def test_app_loads_with_all_tabs_and_no_exceptions(db):
    at = _app().run()
    assert not at.exception
    assert len(at.tabs) == 9


def test_guests_get_isolated_ids_per_session(db):
    a, b = _app().run(), _app().run()
    assert a.session_state["user_id"] != b.session_state["user_id"] and a.session_state["user_id"].startswith("guest-")


def test_add_to_cart_and_order_flow_is_scoped_to_user(db):
    uid = auth.register("asha", "correct horse", iterations=1000)
    at = _app(uid, "asha").run()
    next(b for b in at.button if b.label == "Add to cart").click(); at.run()
    assert len(cart.get_cart(user_id=uid)) == 1 and cart.get_cart(user_id="guest-other") == []
    _click(at, "Create order record")
    assert not at.exception and cart.list_orders(user_id=uid)[0]["status"] == "created" and cart.get_cart(user_id=uid) == []


def test_second_scan_triggers_visible_revision_and_revert_restores_routine(db):
    uid = auth.register("asha", "correct horse", iterations=1000)
    storage.save_scan(_scan("t1", "2026-10-01", redness=80, moisture=70), user_id=uid)
    storage.save_scan(_scan("t2", "2026-10-26", redness=58, moisture=72), user_id=uid)
    assert run_adaptive_loop(storage.get_scans(user_id=uid), uid, "Low", [])["outcome"] == "revised"
    at = _app(uid, "asha").run()
    _click(at, "Preview labelled demo fallback")
    assert not at.exception
    assert any("On hold" in w.value for w in at.warning)
    _click(at, "Revert this revision")
    assert not any("On hold" in w.value for w in at.warning)


def test_delete_my_data_clears_data_but_keeps_login(db):
    uid = auth.register("asha", "correct horse", iterations=1000)
    storage.save_scan(_scan("t1", "2026-10-01", redness=80), user_id=uid)
    at = _app(uid, "asha").run()
    _click(at, "Delete my SkinWise data")
    assert storage.get_scans(user_id=uid) == [] and auth.authenticate("asha", "correct horse") == uid
