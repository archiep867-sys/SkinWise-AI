import pytest
from youcam_client import (YouCamError, analyze_skin, check_connection, extract_score_info, run_makeup_vto)
from skincare import parse_analysis
from tests.fakes import FakeYouCam, make_zip


def _run(fake, **kw):
    return analyze_skin("KEY", b"jpgbytes", "me.jpg", "image/jpeg", session=fake, poll_interval_seconds=0, **kw)


def test_full_skin_flow_downloads_zip_and_parses_scores():
    fake = FakeYouCam(polls_before_success=2)
    result = _run(fake)
    assert result["task_id"] == "TASK123"
    parsed = parse_analysis(result["result"])
    assert {m["label"] for m in parsed["metrics"]} >= {"Acne", "Moisture", "Redness", "Wrinkles"}
    methods = [c[0] for c in fake.calls]
    assert methods.index("PUT") < methods.index("GET")        # upload happens before polling


def test_task_uses_v21_endpoint_file_id_sd_actions_and_zip():
    fake = FakeYouCam()
    _run(fake)
    task = next(c for c in fake.calls if c[0] == "POST" and "/task/" in c[1])
    assert task[1].endswith("/s2s/v2.1/task/skin-analysis")
    assert task[3]["src_file_id"] == "FILE123" and task[3]["format"] == "zip"
    assert not any(a.startswith("hd_") for a in task[3]["dst_actions"])


def test_api_key_is_not_sent_to_signed_upload_or_result_urls():
    fake = FakeYouCam()
    _run(fake)
    for method, url, headers, _ in fake.calls:
        if url.startswith("https://storage.example.com"):
            assert not headers or "Authorization" not in headers


def test_file_path_falls_back_when_specific_endpoint_404s():
    fake = FakeYouCam(reject_paths={"/s2s/v2.1/file/skin-analysis", "/s2s/v2.0/file/skin-analysis"})
    _run(fake)
    file_posts = [c[1] for c in fake.calls if c[0] == "POST" and "/file" in c[1]]
    assert file_posts[-1].endswith("/s2s/v2.0/file") and len(file_posts) == 3


@pytest.mark.parametrize("code,category", [("error_src_face_too_small", "no_face"), ("error_lighting_dark", "image_quality"),
                                           ("error_src_face_out_of_bound", "no_face"), ("weird", "analysis_failed")])
def test_provider_task_errors_become_friendly_categories(code, category):
    fake = FakeYouCam(final_state="error", task_error=code)
    with pytest.raises(YouCamError) as exc:
        _run(fake)
    assert exc.value.category == category


def test_timeout_is_reported():
    fake = FakeYouCam(polls_before_success=10**6)
    with pytest.raises(YouCamError) as exc:
        analyze_skin("KEY", b"x", "a.jpg", "image/jpeg", session=fake, timeout_seconds=0.05, poll_interval_seconds=0.01)
    assert exc.value.category == "timeout"


def test_missing_key_and_non_https_host_are_rejected():
    with pytest.raises(YouCamError) as e1:
        analyze_skin("", b"x", "a.jpg", "image/jpeg")
    assert e1.value.category == "not_configured"
    with pytest.raises(YouCamError) as e2:
        analyze_skin("K", b"x", "a.jpg", "image/jpeg", base_url="http://insecure.example.com")
    assert e2.value.category == "configuration"


def test_extract_score_info_rejects_bad_zip():
    with pytest.raises(YouCamError):
        extract_score_info(b"not a zip")
    assert extract_score_info(make_zip())["all"]["score"] == 75.75


def test_vto_flow_returns_image_and_posts_effects():
    fake = FakeYouCam()
    effects = [{"category": "lip_color"}]
    out = run_makeup_vto("KEY", b"jpg", "me.jpg", "image/jpeg", effects, session=fake, poll_interval_seconds=0)
    assert out["image_bytes"].startswith(b"\xff\xd8")
    task = next(c for c in fake.calls if c[0] == "POST" and "makeup-vto" in c[1] and "/task/" in c[1])
    assert task[3]["effects"] == effects and task[3]["version"] == "1.0"


def test_vto_accepts_dict_style_result():
    fake = FakeYouCam(vto_results={"url": FakeYouCam.RESULT_IMG})
    out = run_makeup_vto("KEY", b"jpg", "me.jpg", "image/jpeg", [{"category": "blush"}], session=fake, poll_interval_seconds=0)
    assert out["image_url"] == FakeYouCam.RESULT_IMG


def test_check_connection_requests_slot_but_starts_no_task():
    fake = FakeYouCam()
    info = check_connection("KEY", session=fake)
    assert info["ok"] and not any("/task/" in c[1] for c in fake.calls)
