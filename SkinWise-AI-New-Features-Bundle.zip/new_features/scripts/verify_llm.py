"""Check the optional LLM coach with your own key: python scripts/verify_llm.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dotenv import load_dotenv
load_dotenv()
from differentiators import llm_coach_reply

answer, mode = llm_coach_reply("How do I introduce a new serum safely?", None, None, "Oily", ["Acne / breakouts"], "Low", [], "₹500–₹1,000")
print("MODE:", mode); print(answer)
sys.exit(0 if mode.startswith("LLM") else 1)
