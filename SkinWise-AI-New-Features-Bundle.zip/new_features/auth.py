"""Minimal username/password accounts (PBKDF2-HMAC-SHA256, per-user salt, lockout on repeated failures).

This gives each person a private, persistent data scope. It is intentionally small: no e-mail
verification or password reset. Do not reuse an important password in a hackathon prototype.
"""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import time
from pathlib import Path

from storage import connect

ITERATIONS = 310_000
MAX_FAILURES = 5
LOCK_SECONDS = 300
_USERNAME_RE = re.compile(r"^[a-z0-9._-]{3,32}$")


class AuthError(ValueError):
    pass


def normalize_username(username: str) -> str:
    return (username or "").strip().lower()


def user_id_for(username: str) -> str:
    return f"user:{normalize_username(username)}"


def _hash(password: str, salt: bytes, iterations: int) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations).hex()


def register(username: str, password: str, db_path: str | Path | None = None, *, iterations: int = ITERATIONS) -> str:
    name = normalize_username(username)
    if not _USERNAME_RE.match(name):
        raise AuthError("Username must be 3-32 characters: letters, numbers, dot, dash or underscore.")
    if len(password or "") < 8:
        raise AuthError("Password must be at least 8 characters.")
    salt = secrets.token_bytes(16)
    with connect(db_path) as conn:
        if conn.execute("SELECT 1 FROM users WHERE username=?", (name,)).fetchone():
            raise AuthError("That username is already taken.")
        conn.execute("INSERT INTO users(username, password_hash, salt, iterations) VALUES (?, ?, ?, ?)",
                     (name, _hash(password, salt, iterations), salt.hex(), iterations))
    return user_id_for(name)


def authenticate(username: str, password: str, db_path: str | Path | None = None, *, now: float | None = None) -> str:
    """Return the user_id on success; raise AuthError otherwise."""
    name = normalize_username(username)
    now = time.time() if now is None else now
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE username=?", (name,)).fetchone()
        if row is None:
            # Burn comparable time so unknown usernames are not distinguishable by speed.
            _hash(password or "", b"\x00" * 16, 1000)
            raise AuthError("Incorrect username or password.")
        if row["locked_until"] > now:
            raise AuthError("Too many failed attempts. Try again in a few minutes.")
        expected = row["password_hash"]
        actual = _hash(password or "", bytes.fromhex(row["salt"]), row["iterations"])
        if hmac.compare_digest(expected, actual):
            conn.execute("UPDATE users SET failed_attempts=0, locked_until=0 WHERE username=?", (name,))
            return user_id_for(name)
        failures = row["failed_attempts"] + 1
        locked = now + LOCK_SECONDS if failures >= MAX_FAILURES else 0
        conn.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE username=?",
                     (0 if locked else failures, locked, name))
    raise AuthError("Incorrect username or password.")
