# Devpost text (edit after your live test)

**Track:** Skin AI

## Inspiration
People wonder about their skin right before a purchase or after a bad breakout, but scores alone don't tell them what to do, and nothing tells them whether it worked.

## What it does
SkinWise turns a YouCam skin scan into action and then checks the result. Upload a selfie → lowest-scoring areas → a conservative AM/PM routine fitted to sensitivity, exclusions and budget → matched products with cheaper swaps → a cart and per-retailer shopping list. Re-scan and the app **automatically revises the routine** when a score drops (simplify/soften only, revertible, escalates to a dermatologist on sharp falls), reports measured progress next to routine adherence, previews makeup looks with YouCam Virtual Try-On, and prepares a summary for a clinician.

## YouCam APIs used
- **AI Skin Analysis v2.1:** File API upload, async task, polling, score_info.json (raw and UI scores, per-region scores, skin age).
- **AI Makeup Virtual Try-On:** blush and lip effects on the user's photo.

## How we built it
Python + Streamlit, SQLite per-user storage, PBKDF2 accounts, Pillow for EXIF/resize to the API limits. 100 automated tests including an offline fake of YouCam's API that exercises upload → task → poll → ZIP → parse, plus headless UI tests.

## Challenges
Reading YouCam's scale correctly (higher = healthier; our first version had it backwards), resizing phone photos to API limits, and keeping automatic routine changes safe: they only ever remove or soften, and never claim causation.

## Accomplishments
A closed loop from scan to routine to re-scan, built conservatively; honest handling of what the data can and can't show.

## What's next
Verified live product feed, retailer affiliate integrations, managed database, clinician partnerships for real booking.

## Limitations (we say this in the app too)
Photo-based scores are affected by lighting and camera. Not a medical device or diagnosis. Catalogue prices are indicative. No in-app purchasing or appointment booking.

## Built with
python, streamlit, sqlite, pillow, youcam-api
