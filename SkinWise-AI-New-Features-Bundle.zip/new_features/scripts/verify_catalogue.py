"""Catalogue verification helper.

  python scripts/verify_catalogue.py --template   # writes data/catalogue_overrides.csv with one row per product
  python scripts/verify_catalogue.py --status     # shows how many products have a verified_on date

Workflow: open each product's retailer page, copy the real price, the full INCI list and the exact product URL into
the CSV, set verified_on to today's date, and restart the app. Only rows you fill in are applied.
"""
import argparse, csv, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import products

OUT = Path(__file__).resolve().parent.parent / "data" / "catalogue_overrides.csv"
ap = argparse.ArgumentParser(); ap.add_argument("--template", action="store_true"); ap.add_argument("--status", action="store_true")
a = ap.parse_args()
if a.template:
    if OUT.exists():
        sys.exit(f"{OUT} exists; refusing to overwrite.")
    OUT.parent.mkdir(exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["id", "name (reference only)", "price_inr", "key_ingredients", "buy_link", "verified_on"])
        for p in products.PRODUCTS:
            w.writerow([p["id"], p["name"], "", "", "", ""])
    print("Wrote", OUT)
else:
    s = products.catalogue_status(); print(s, "| overrides applied:", products.APPLIED_OVERRIDES)
