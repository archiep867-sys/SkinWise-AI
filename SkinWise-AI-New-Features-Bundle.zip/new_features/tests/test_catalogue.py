import products
from products import apply_overrides, catalogue_status, get_product, retailer_links, retailer_name


def test_override_csv_updates_price_ingredients_and_verification(tmp_path):
    items = [dict(p) for p in products.PRODUCTS]
    pid = items[0]["id"]
    f = tmp_path / "o.csv"
    f.write_text(f"id,price_inr,key_ingredients,buy_link,verified_on\n{pid},355,Salicylic acid 2%,https://www.nykaa.com/x,2026-10-27\nbad-id,1,,,\n")
    assert apply_overrides(items, f) == 1
    assert items[0]["price_inr"] == 355 and items[0]["verified_on"] == "2026-10-27" and items[0]["buy_link"].endswith("/x")


def test_override_rejects_bad_values(tmp_path):
    items = [dict(p) for p in products.PRODUCTS]
    pid = items[0]["id"]; original = items[0]["price_inr"]
    f = tmp_path / "o.csv"
    f.write_text(f"id,price_inr,key_ingredients,buy_link,verified_on\n{pid},-5,,http://insecure.example.com,\n{pid},abc,,,\n")
    apply_overrides(items, f)
    assert items[0]["price_inr"] == original and items[0]["buy_link"].startswith("https://www.nykaa.com")


def test_missing_override_file_is_fine(tmp_path):
    assert apply_overrides([], tmp_path / "nope.csv") == 0


def test_status_and_links():
    s = catalogue_status()
    assert s["total"] == len(products.PRODUCTS) and s["verified"] + s["unverified"] == s["total"]
    links = retailer_links(products.PRODUCTS[0])
    assert [l["retailer"] for l in links] == ["Nykaa", "Amazon.in", "Purplle"] and all(l["url"].startswith("https://") for l in links)
    assert retailer_name("https://www.nykaa.com/search") == "Nykaa" and get_product("zzz") is None
