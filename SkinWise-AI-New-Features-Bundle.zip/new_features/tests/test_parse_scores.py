from skincare import parse_analysis
from tests.fakes import SD_SCORE_INFO


def test_sd_score_info_is_parsed_with_ui_and_raw():
    p = parse_analysis(SD_SCORE_INFO)
    by = {m["label"]: m for m in p["metrics"]}
    assert by["Moisture"]["ui_score"] == 70 and by["Moisture"]["raw_score"] == 48.69
    assert by["Moisture"]["value"] == 70            # display = UI score
    assert by["Overall score"]["value"] == 75.8
    assert p["skin_age"] == 37
    assert all(m["direction"] == "higher_is_better" for m in p["metrics"])


def test_lowest_scores_are_the_concerns_not_the_highest():
    p = parse_analysis(SD_SCORE_INFO)
    assert p["concerns"][0] == "Wrinkles"           # raw 36 is lowest
    assert "Acne" not in p["concerns"]              # raw 92 is the healthiest area
    assert "most room for improvement" in p["summary"]


def test_hd_regions_are_kept_and_whole_is_the_headline():
    raw = {"hd_pore": {"forehead": {"raw_score": 79.6, "ui_score": 80}, "nose": {"raw_score": 29.1, "ui_score": 58},
                       "whole": {"raw_score": 49.2, "ui_score": 67}}}
    m = parse_analysis(raw)["metrics"][0]
    assert m["label"] == "Pores" and m["value"] == 67
    assert m["regions"]["nose"]["raw_score"] == 29.1


def test_list_shape_with_type_field():
    raw = {"data": {"results": {"output": [{"type": "acne", "ui_score": 80, "raw_score": 83.2, "mask_urls": ["https://x"]},
                                           {"type": "moisture", "ui_score": 65, "raw_score": 50.1}]}}}
    labels = {m["label"]: m["value"] for m in parse_analysis(raw)["metrics"]}
    assert labels == {"Acne": 80, "Moisture": 65}


def test_unknown_payload_does_not_invent_scores():
    p = parse_analysis({"data": {"something": "else"}})
    assert p["metrics"] == [] and "no supported numeric scores" in p["summary"]
