"""Shopping cart, orders and optional Razorpay payment links.

IMPORTANT scope notes
- SkinWise does not stock, sell or ship products. The catalogue lists third-party brands. A "checkout" here
  creates an *order record and a per-retailer shopping list* with links so the person can buy from the retailer.
  There is no direct retailer API integration (that needs partner/affiliate agreements).
- Optional payments use Razorpay Payment Links. Intended for TEST-MODE demos (keys starting ``rzp_test_``).
  Do not collect real money for products you do not fulfil.
"""
from __future__ import annotations

import os
from typing import Any

import requests

from products import PRODUCTS, get_product, retailer_name
from storage import GUEST, connect

RAZORPAY_API = "https://api.razorpay.com/v1"
MAX_QTY = 10


class CartError(ValueError):
    pass


def add_to_cart(product_id: str, qty: int = 1, db_path=None, *, user_id: str = GUEST) -> None:
    if get_product(product_id) is None:
        raise CartError("Unknown product.")
    with connect(db_path) as conn:
        row = conn.execute("SELECT qty FROM cart_items WHERE user_id=? AND product_id=?", (user_id, product_id)).fetchone()
        new_qty = min(MAX_QTY, (row["qty"] if row else 0) + max(1, int(qty)))
        conn.execute("INSERT INTO cart_items(user_id, product_id, qty) VALUES (?, ?, ?) "
                     "ON CONFLICT(user_id, product_id) DO UPDATE SET qty=excluded.qty", (user_id, product_id, new_qty))


def set_quantity(product_id: str, qty: int, db_path=None, *, user_id: str = GUEST) -> None:
    with connect(db_path) as conn:
        if int(qty) <= 0:
            conn.execute("DELETE FROM cart_items WHERE user_id=? AND product_id=?", (user_id, product_id))
        else:
            conn.execute("UPDATE cart_items SET qty=? WHERE user_id=? AND product_id=?", (min(MAX_QTY, int(qty)), user_id, product_id))


def clear_cart(db_path=None, *, user_id: str = GUEST) -> None:
    with connect(db_path) as conn:
        conn.execute("DELETE FROM cart_items WHERE user_id=?", (user_id,))


def get_cart(db_path=None, *, user_id: str = GUEST) -> list[dict[str, Any]]:
    with connect(db_path) as conn:
        rows = conn.execute("SELECT product_id, qty FROM cart_items WHERE user_id=? ORDER BY rowid", (user_id,)).fetchall()
    items = []
    for row in rows:
        product = get_product(row["product_id"])
        if product:  # silently drop items removed from the catalogue
            items.append({"product": product, "qty": row["qty"], "line_total_inr": product["price_inr"] * row["qty"]})
    return items


def cart_summary(items: list[dict[str, Any]]) -> dict[str, Any]:
    by_retailer: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        by_retailer.setdefault(retailer_name(item["product"]["buy_link"]), []).append(item)
    return {"count": sum(i["qty"] for i in items), "subtotal_inr": sum(i["line_total_inr"] for i in items),
            "by_retailer": by_retailer, "unverified": [i["product"]["name"] for i in items if not i["product"].get("verified_on")]}


def place_order(db_path=None, *, user_id: str = GUEST, note: str = "") -> dict[str, Any]:
    """Snapshot the cart into an order record (prices frozen at this moment) and empty the cart."""
    items = get_cart(db_path, user_id=user_id)
    if not items:
        raise CartError("Your cart is empty.")
    summary = cart_summary(items)
    payload = {"note": note[:500], "items": [
        {"product_id": i["product"]["id"], "name": i["product"]["name"], "qty": i["qty"],
         "unit_price_inr": i["product"]["price_inr"], "retailer": retailer_name(i["product"]["buy_link"]),
         "buy_link": i["product"]["buy_link"], "price_verified_on": i["product"].get("verified_on")} for i in items],
        "price_note": "Indicative catalogue prices; the retailer's price at purchase time applies. Shipping and taxes not included."}
    import json
    with connect(db_path) as conn:
        cur = conn.execute("INSERT INTO orders(user_id, status, total_inr, payload_json) VALUES (?, 'created', ?, ?)",
                           (user_id, summary["subtotal_inr"], json.dumps(payload, ensure_ascii=False)))
        order_id = cur.lastrowid
    clear_cart(db_path, user_id=user_id)
    return get_order(order_id, db_path, user_id=user_id)


def _row_to_order(row) -> dict[str, Any]:
    import json
    return {"id": row["id"], "status": row["status"], "total_inr": row["total_inr"], "payment_link_id": row["payment_link_id"],
            "created_at": row["created_at"], **json.loads(row["payload_json"])}


def get_order(order_id: int, db_path=None, *, user_id: str = GUEST) -> dict[str, Any]:
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM orders WHERE id=? AND user_id=?", (order_id, user_id)).fetchone()
    if row is None:
        raise CartError("Order not found.")
    return _row_to_order(row)


def list_orders(db_path=None, *, user_id: str = GUEST, limit: int = 20) -> list[dict[str, Any]]:
    with connect(db_path) as conn:
        rows = conn.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit)).fetchall()
    return [_row_to_order(r) for r in rows]


def update_order(order_id: int, status: str, payment_link_id: str | None = None, db_path=None, *, user_id: str = GUEST) -> None:
    if status not in {"created", "payment_pending", "paid", "cancelled", "expired"}:
        raise CartError("Invalid order status.")
    with connect(db_path) as conn:
        if payment_link_id is not None:
            conn.execute("UPDATE orders SET status=?, payment_link_id=? WHERE id=? AND user_id=?", (status, payment_link_id, order_id, user_id))
        else:
            conn.execute("UPDATE orders SET status=? WHERE id=? AND user_id=?", (status, order_id, user_id))


def order_shopping_list(order: dict[str, Any]) -> str:
    """Plain-text per-retailer list the person can keep or share."""
    lines = [f"SkinWise AI shopping list - order #{order['id']}", ""]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for item in order["items"]:
        grouped.setdefault(item["retailer"], []).append(item)
    for retailer, items in grouped.items():
        lines.append(f"{retailer}")
        for i in items:
            lines.append(f"  - {i['name']} x{i['qty']}  (~Rs {i['unit_price_inr'] * i['qty']})  {i['buy_link']}")
    lines += ["", f"Indicative total: Rs {order['total_inr']}", order.get("price_note", "")]
    return "\n".join(lines)


# --------------------------------------------------------------------------- Razorpay (optional, test mode)
def payments_configured() -> bool:
    return bool(os.getenv("RAZORPAY_KEY_ID", "").strip() and os.getenv("RAZORPAY_KEY_SECRET", "").strip())


def payments_mode() -> str:
    key = os.getenv("RAZORPAY_KEY_ID", "").strip()
    return "test" if key.startswith("rzp_test_") else ("live" if key else "off")


def create_payment_link(order: dict[str, Any], key_id: str, key_secret: str, callback_url: str | None = None,
                        session: Any = requests) -> dict[str, Any]:
    """Create a Razorpay Payment Link for the order total (amount in paise). Returns {id, short_url, status}."""
    if order["total_inr"] < 1:
        raise CartError("Order total must be at least Rs 1.")
    body: dict[str, Any] = {
        "amount": int(order["total_inr"]) * 100, "currency": "INR", "accept_partial": False,
        "description": f"SkinWise AI order #{order['id']}", "reference_id": f"skinwise-{order['id']}",
        "notes": {"order_id": str(order["id"])},
    }
    if callback_url and callback_url.startswith("https://"):
        body.update({"callback_url": callback_url, "callback_method": "get"})
    try:
        resp = session.post(f"{RAZORPAY_API}/payment_links", auth=(key_id, key_secret), json=body, timeout=20)
    except requests.exceptions.RequestException as exc:
        raise CartError("Could not reach Razorpay. Check your connection and try again.") from exc
    if resp.status_code >= 400:
        raise CartError(f"Razorpay rejected the request (HTTP {resp.status_code}). Check your keys and account mode.")
    data = resp.json()
    if not data.get("short_url") or not data.get("id"):
        raise CartError("Razorpay returned an unexpected response.")
    return {"id": data["id"], "short_url": data["short_url"], "status": data.get("status", "created")}


def fetch_payment_link_status(link_id: str, key_id: str, key_secret: str, session: Any = requests) -> str:
    """Return the Razorpay payment-link status: created | partially_paid | expired | cancelled | paid."""
    try:
        resp = session.get(f"{RAZORPAY_API}/payment_links/{link_id}", auth=(key_id, key_secret), timeout=20)
    except requests.exceptions.RequestException as exc:
        raise CartError("Could not reach Razorpay. Try again shortly.") from exc
    if resp.status_code >= 400:
        raise CartError(f"Razorpay returned HTTP {resp.status_code} while checking the payment.")
    return str(resp.json().get("status", "unknown"))


RAZORPAY_TO_ORDER_STATUS = {"paid": "paid", "cancelled": "cancelled", "expired": "expired"}
