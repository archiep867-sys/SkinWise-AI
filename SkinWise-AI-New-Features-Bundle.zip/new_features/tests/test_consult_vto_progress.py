import pytest
from derm import (build_clinician_summary, build_consult_request, mailto_link, urgent_screen, URGENT_FLAGS)
from vto import LOOKS, build_effects
from progress import adherence_between, progress_report, report_text


def scan(date, **raw):
    return {"date": date, "source": "Live YouCam Skin Analysis v2.1",
            "metrics": [{"label": k.replace("_", " ").title(), "value": v, "raw_score": v} for k, v in raw.items()]}


def test_urgent_flags_block_booking_message():
    flag = next(iter(URGENT_FLAGS))
    r = urgent_screen([flag])
    assert r["urgent"] and "in-person medical care" in r["message"]
    assert not urgent_screen([])["urgent"]


def test_clinician_summary_contains_facts_and_disclaimer_but_no_diagnosis():
    live = [scan("2026-10-26", redness=60, moisture=70), scan("2026-09-26", redness=80, moisture=65)]
    text = build_clinician_summary({"skin_type": "Oily", "concerns": ["Acne / breakouts"], "sensitivity": "High", "avoid": ["Fragrance"]},
                                   live, {"morning": [{"name": "Gentle cleanser"}], "evening": [], "holds": ["Pause acids"]},
                                   [{"date": "2026-10-25", "skin_feel": "Dry or tight", "adherence_days": 5}], [], reason="Redness not settling")
    assert "Redness not settling" in text and "Redness: -20" in text and "Pause acids" in text
    assert "Not a clinical record or a diagnosis" in text
    assert text.lower().count("diagnos") == 1          # only the disclaimer; the summary never states a diagnosis


def test_consult_request_is_honest_about_not_booking():
    req = build_consult_request(mode="Teleconsultation", city="Mumbai", reason="General skin check", timing="weekends", contact_note="", summary_included=True)
    assert "does not book" in req["status"]
    with pytest.raises(ValueError):
        build_consult_request(mode="Home visit", city="", reason="x", timing="", contact_note="", summary_included=False)


def test_mailto_is_url_encoded_and_length_limited():
    req = build_consult_request(mode="In-person", city="Pune", reason="Acne", timing="", contact_note="", summary_included=True)
    link = mailto_link("clinic@example.com", req, "x" * 5000)
    assert link.startswith("mailto:clinic%40example.com?subject=") and len(link) < 3500 and " " not in link


def test_vto_effects_match_documented_schema():
    for look in LOOKS:
        effects = build_effects(look)
        cats = [e["category"] for e in effects]
        assert cats == ["skin_smooth", "blush", "lip_color"]
        lip = effects[-1]
        assert lip["shape"]["name"] == "original" and lip["style"]["type"] == "full"
        assert all(0 <= p["colorIntensity"] <= 100 for e in effects for p in e.get("palettes", []))
        assert len(effects[1]["palettes"]) == 1       # 1color1 pattern needs exactly one palette


def test_vto_custom_lip_validation_and_gloss_required_fields():
    assert build_effects("Soft berry", "#112233", 70)[-1]["palettes"][0]["color"] == "#112233"
    gloss = build_effects("Soft berry", lip_finish="gloss")[-1]["palettes"][0]
    assert gloss["gloss"] == 60 and gloss["transparencyIntensity"] == 40
    for bad in ("red", "#12345", "#gggggg"):
        with pytest.raises(ValueError):
            build_effects("Soft berry", bad)
    with pytest.raises(ValueError):
        build_effects("Soft berry", lip_intensity=101)
    with pytest.raises(ValueError):
        build_effects("Nope")
    assert len(build_effects("Soft berry", include_blush=False)) == 2


def test_progress_report_labels_direction_correctly_and_is_honest():
    live = [scan("2026-10-26", moisture=75, redness=60, acne=71), scan("2026-10-01", moisture=60, redness=80, acne=70)]
    checkins = [{"checkin_date": "2026-10-10", "completed": 1}, {"checkin_date": "2026-10-10", "completed": 0},
                {"checkin_date": "2026-10-11", "completed": 1}, {"checkin_date": "2026-09-01", "completed": 1}]
    rep = progress_report(live, checkins)
    assert [r["concern"] for r in rep["improved"]] == ["Moisture"]
    assert [r["concern"] for r in rep["declined"]] == ["Redness"]
    assert [r["concern"] for r in rep["steady"]] == ["Acne"]
    assert rep["adherence"] == {"days_logged": 2, "avg_completion_pct": 75.0}       # Sept check-in is outside the window
    assert any("does not show that your routine caused" in n for n in rep["notes"])
    assert "Declined: Redness -20" in report_text(rep)


def test_progress_needs_two_scans_and_warns_on_short_gap():
    assert progress_report([scan("2026-10-26", moisture=70)], [])["available"] is False
    rep = progress_report([scan("2026-10-05", moisture=70), scan("2026-10-01", moisture=60)], [])
    assert any("less than two weeks" in n for n in rep["notes"]) and any("No routine check-ins" in n for n in rep["notes"])


def test_adherence_handles_empty():
    assert adherence_between([], "2026-10-01", "2026-10-26")["avg_completion_pct"] is None
