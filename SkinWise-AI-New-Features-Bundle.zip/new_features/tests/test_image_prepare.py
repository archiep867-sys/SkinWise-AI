from io import BytesIO
import pytest
from PIL import Image
from image_quality import prepare_image, inspect_image


def _img(size, exif_orientation=None, fmt="JPEG"):
    im = Image.new("RGB", size, (180, 150, 140))
    for x in range(0, size[0], 40):          # texture so contrast is not flat
        for y in range(0, size[1], 40):
            im.putpixel((x, y), (30, 30, 30))
    buf = BytesIO()
    if exif_orientation:
        exif = Image.Exif(); exif[0x0112] = exif_orientation
        im.save(buf, format=fmt, exif=exif)
    else:
        im.save(buf, format=fmt)
    return buf.getvalue()


def test_large_phone_photo_is_downscaled_to_api_limit():
    data, ctype = prepare_image(_img((3000, 4000)))
    out = Image.open(BytesIO(data))
    assert max(out.size) <= 1920 and ctype == "image/jpeg"
    assert abs(out.size[0] / out.size[1] - 0.75) < 0.01        # aspect ratio preserved


def test_exif_rotation_is_applied():
    data, _ = prepare_image(_img((800, 600), exif_orientation=6))   # 6 = rotate 90 CW -> portrait
    out = Image.open(BytesIO(data))
    assert out.size[1] > out.size[0]


def test_too_small_is_rejected_by_prepare_and_inspect():
    small = _img((300, 300))
    with pytest.raises(ValueError):
        prepare_image(small)
    assert inspect_image(small)["ok"] is False


def test_non_image_rejected():
    with pytest.raises(ValueError):
        prepare_image(b"nope")


def test_inspect_flags_resize_needed():
    assert inspect_image(_img((2400, 3200)))["needs_resize"] is True


def test_vto_limit_is_stricter():
    data, _ = prepare_image(_img((3000, 4000)), max_long_side=1800)
    assert max(Image.open(BytesIO(data)).size) <= 1800
