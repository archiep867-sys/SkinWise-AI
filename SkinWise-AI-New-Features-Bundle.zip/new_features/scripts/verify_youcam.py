"""Live verification against your YouCam account. Run this BEFORE you claim the integration works.

    python scripts/verify_youcam.py --photo selfie.jpg            # connection + real skin scan (uses units)
    python scripts/verify_youcam.py --photo selfie.jpg --vto      # also one makeup try-on render (1 unit)
    python scripts/verify_youcam.py --connection-only             # key + host check, starts no task

Prints exactly what YouCam returned so you can confirm the parser maps it correctly.
"""
import argparse, json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dotenv import load_dotenv
load_dotenv()
from image_quality import VTO_MAX_LONG_SIDE, prepare_image
from skincare import parse_analysis
from vto import build_effects
from youcam_client import DEFAULT_BASE_URL, YouCamError, analyze_skin, check_connection, run_makeup_vto


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--photo"); ap.add_argument("--vto", action="store_true"); ap.add_argument("--connection-only", action="store_true")
    a = ap.parse_args()
    key = os.getenv("YOUCAM_API_KEY", "").strip(); base = os.getenv("YOUCAM_API_BASE_URL", DEFAULT_BASE_URL)
    try:
        print("1. connection:", check_connection(key, base))
        if a.connection_only:
            return 0
        if not a.photo:
            print("Pass --photo to run a real scan."); return 2
        data, ctype = prepare_image(Path(a.photo).read_bytes())
        print(f"2. skin analysis on {len(data)//1024} KB image ...")
        res = analyze_skin(key, data, "selfie.jpg", ctype, base_url=base, result_format=os.getenv("YOUCAM_RESULT_FORMAT", "zip"))
        parsed = parse_analysis(res["result"])
        print("   task:", res["task_id"]); print("   raw keys:", list(res["result"])[:20])
        for m in parsed["metrics"]:
            print(f"   {m['label']:<22} ui={m['ui_score']} raw={m['raw_score']}")
        print("   summary:", parsed["summary"])
        if not parsed["metrics"]:
            print("!! No metrics parsed. Paste the raw keys above into an issue / adjust skincare.CATEGORY_LABELS."); return 1
        if a.vto:
            d2, c2 = prepare_image(Path(a.photo).read_bytes(), max_long_side=VTO_MAX_LONG_SIDE)
            out = run_makeup_vto(key, d2, "selfie.jpg", c2, build_effects("Soft berry"), base_url=base)
            Path("vto_check.jpg").write_bytes(out["image_bytes"]); print("3. VTO ok -> vto_check.jpg")
        print("\nOK. Now check your YouCam console for units used.")
        return 0
    except YouCamError as exc:
        print(f"FAILED [{exc.category}]: {exc}"); return 1


if __name__ == "__main__":
    raise SystemExit(main())
