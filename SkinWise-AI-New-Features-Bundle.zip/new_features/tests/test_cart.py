import pytest
from cart import (CartError, add_to_cart, cart_summary, clear_cart, create_payment_link, fetch_payment_link_status, get_cart,
                  list_orders, order_shopping_list, place_order, set_quantity, update_order)
from products import PRODUCTS


class Resp:
    def __init__(self, status, body):
        self.status_code, self._b = status, body
    def json(self):
        return self._b


class FakeRazorpay:
    def __init__(self, status=200, body=None):
        self.status, self.body, self.calls = status, body, []
    def post(self, url, auth=None, json=None, timeout=None):
        self.calls.append((url, auth, json))
        return Resp(self.status, self.body if self.body is not None else {"id": "plink_1", "short_url": "https://rzp.io/i/x", "status": "created"})
    def get(self, url, auth=None, timeout=None):
        self.calls.append((url, auth, None))
        return Resp(self.status, {"status": "paid"})


def test_add_update_remove_and_totals(tmp_path):
    db = tmp_path / "c.db"
    p1, p2 = PRODUCTS[0], PRODUCTS[4]
    add_to_cart(p1["id"], 1, db, user_id="u"); add_to_cart(p1["id"], 1, db, user_id="u"); add_to_cart(p2["id"], 1, db, user_id="u")
    items = get_cart(db, user_id="u")
    assert {i["product"]["id"]: i["qty"] for i in items} == {p1["id"]: 2, p2["id"]: 1}
    s = cart_summary(items)
    assert s["subtotal_inr"] == p1["price_inr"] * 2 + p2["price_inr"] and s["count"] == 3
    set_quantity(p1["id"], 0, db, user_id="u")
    assert [i["product"]["id"] for i in get_cart(db, user_id="u")] == [p2["id"]]


def test_quantity_is_capped_and_unknown_product_rejected(tmp_path):
    db = tmp_path / "c.db"
    for _ in range(15):
        add_to_cart(PRODUCTS[0]["id"], 1, db, user_id="u")
    assert get_cart(db, user_id="u")[0]["qty"] == 10
    with pytest.raises(CartError):
        add_to_cart("nope", 1, db, user_id="u")


def test_carts_are_per_user(tmp_path):
    db = tmp_path / "c.db"
    add_to_cart(PRODUCTS[0]["id"], 1, db, user_id="a")
    assert get_cart(db, user_id="b") == []


def test_place_order_snapshots_prices_and_empties_cart(tmp_path):
    db = tmp_path / "c.db"
    add_to_cart(PRODUCTS[0]["id"], 2, db, user_id="u")
    order = place_order(db, user_id="u", note="gift")
    assert order["total_inr"] == PRODUCTS[0]["price_inr"] * 2 and order["items"][0]["qty"] == 2
    assert get_cart(db, user_id="u") == []
    assert list_orders(db, user_id="u")[0]["id"] == order["id"] and list_orders(db, user_id="other") == []
    with pytest.raises(CartError):
        place_order(db, user_id="u")             # empty now
    text = order_shopping_list(order)
    assert "Nykaa" in text and PRODUCTS[0]["name"] in text


def test_orders_cannot_be_read_by_other_users(tmp_path):
    db = tmp_path / "c.db"
    add_to_cart(PRODUCTS[0]["id"], 1, db, user_id="u")
    order = place_order(db, user_id="u")
    from cart import get_order
    with pytest.raises(CartError):
        get_order(order["id"], db, user_id="intruder")


def test_razorpay_link_amount_is_in_paise_and_uses_basic_auth():
    fake = FakeRazorpay()
    link = create_payment_link({"id": 7, "total_inr": 899}, "rzp_test_k", "secret", callback_url="https://app.example.com", session=fake)
    url, auth, body = fake.calls[0]
    assert url.endswith("/payment_links") and auth == ("rzp_test_k", "secret")
    assert body["amount"] == 89900 and body["currency"] == "INR" and body["reference_id"] == "skinwise-7"
    assert link["short_url"].startswith("https://")


def test_razorpay_errors_are_friendly():
    with pytest.raises(CartError):
        create_payment_link({"id": 1, "total_inr": 100}, "k", "s", session=FakeRazorpay(status=401, body={}))
    with pytest.raises(CartError):
        create_payment_link({"id": 1, "total_inr": 0}, "k", "s", session=FakeRazorpay())
    assert fetch_payment_link_status("plink_1", "k", "s", session=FakeRazorpay()) == "paid"


def test_update_order_status_validates(tmp_path):
    db = tmp_path / "c.db"
    add_to_cart(PRODUCTS[0]["id"], 1, db, user_id="u")
    order = place_order(db, user_id="u")
    update_order(order["id"], "payment_pending", "plink_1", db, user_id="u")
    assert list_orders(db, user_id="u")[0]["payment_link_id"] == "plink_1"
    with pytest.raises(CartError):
        update_order(order["id"], "shipped", None, db, user_id="u")
