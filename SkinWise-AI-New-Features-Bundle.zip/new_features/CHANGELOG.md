# Changelog

## 2.0
**Fixes (found by checking against YouCam's docs)**
- Score direction: higher = healthier. Concerns are now the *lowest* scores; a *drop* triggers review (was inverted).
- Parser reads `ui_score` / `raw_score` objects, region sub-scores, skin age, overall score (it previously could not read them). Comparisons use raw scores.
- Photos are EXIF-corrected and resized to the API limits before upload (previously raw phone photos would be rejected).
- Result handling for the default ZIP format; provider error codes mapped to friendly guidance; File API path fallback.
- `.gitignore` had literal `\n` characters and did not ignore `.env`. Fixed.

**New**
- Automatic adaptive routine revisions (stored, revertible), measured progress report
- Accounts, per-user data isolation, guest session isolation, DB migration
- Cart, orders, shopping list export, optional Razorpay test-mode links
- YouCam Makeup Virtual Try-On look preview
- Dermatologist hand-off (urgent screen, clinician summary, saved request, email draft)
- Catalogue verification workflow and retailer links
- Dockerfile, docker-compose, render.yaml; scripts to verify the live API, LLM and catalogue
- Tests: 28 → 100
