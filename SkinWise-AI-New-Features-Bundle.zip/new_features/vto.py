"""AI Makeup Virtual Try-On presets (YouCam ``makeup-vto``, 1 unit per render).

This previews a *makeup look* on the user's own photo. It does not predict skincare results. Effect payloads
follow https://docs.perfectcorp.com/reference/makeup_vto : each effect has a ``category``, palette colours are
"#RRGGBB", intensities are integers 0..100, and lip_color needs a shape from lipshape.json (``original`` is valid).
Blush pattern ``1color1`` (one palette) is taken from the documented blush.json catalogue.
"""
from __future__ import annotations

import re
from typing import Any

HEX = re.compile(r"^#[0-9a-fA-F]{6}$")

LOOKS: dict[str, dict[str, Any]] = {
    "Fresh & natural": {"blush": "#e8a0a0", "blush_intensity": 35, "lip": "#c9737a", "lip_intensity": 45, "smooth": 40},
    "Soft berry": {"blush": "#d86b86", "blush_intensity": 45, "lip": "#a63a5a", "lip_intensity": 60, "smooth": 40},
    "Classic red lip": {"blush": "#e08a8a", "blush_intensity": 30, "lip": "#c8102e", "lip_intensity": 80, "smooth": 40},
    "Nude / office": {"blush": "#d9a39b", "blush_intensity": 30, "lip": "#b97d73", "lip_intensity": 50, "smooth": 40},
}


def _check_hex(value: str, field: str) -> str:
    if not isinstance(value, str) or not HEX.match(value):
        raise ValueError(f"{field} must be a hex colour like #c8102e")
    return value.lower()


def _check_pct(value: int, field: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 100:
        raise ValueError(f"{field} must be an integer from 0 to 100")
    return value


def build_effects(look: str, lip_hex: str | None = None, lip_intensity: int | None = None,
                  include_blush: bool = True, lip_finish: str = "matte") -> list[dict[str, Any]]:
    """Return the ``effects`` array for a preset look, optionally overriding the lip colour/intensity."""
    if look not in LOOKS:
        raise ValueError(f"Unknown look: {look}")
    spec = LOOKS[look]
    lip_colour = _check_hex(lip_hex or spec["lip"], "lip colour")
    lip_pct = _check_pct(lip_intensity if lip_intensity is not None else spec["lip_intensity"], "lip intensity")
    if lip_finish not in {"matte", "gloss"}:
        raise ValueError("lip finish must be 'matte' or 'gloss'")
    palette: dict[str, Any] = {"color": lip_colour, "texture": lip_finish, "colorIntensity": lip_pct}
    if lip_finish == "gloss":  # gloss requires these two fields per the schema
        palette.update({"gloss": 60, "transparencyIntensity": 40})
    effects: list[dict[str, Any]] = [
        {"category": "skin_smooth", "skinSmoothStrength": _check_pct(spec["smooth"], "smooth"), "skinSmoothColorIntensity": _check_pct(spec["smooth"], "smooth")}]
    if include_blush:
        effects.append({"category": "blush", "pattern": {"name": "1color1"},
                        "palettes": [{"color": _check_hex(spec["blush"], "blush"), "texture": "matte",
                                      "colorIntensity": _check_pct(spec["blush_intensity"], "blush intensity")}]})
    effects.append({"category": "lip_color", "shape": {"name": "original"}, "style": {"type": "full"}, "palettes": [palette]})
    return effects
