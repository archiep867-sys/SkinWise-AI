# SkinWise AI v2 — GitHub comparison and new-feature bundle

## Comparison basis
- GitHub repository: https://github.com/archiep867-sys/SkinWise-AI
- Branch checked: `main`
- Current `main` commit checked: `159bd56f587cb28e8e1e28e5c15f4d219d2d6052`
- Uploaded archive: `SkinWise-AI-v2.zip`

This file accompanies the original v2 files. It is a comparison/integration note, not a replacement for the whole app.

## Important result
The archive is a complete application snapshot with new modules, a revised `app.py`, and dependencies between files. The GitHub `main` branch already contains some of the v2 features, so copying every v2 file as “new” would duplicate existing work. In particular, GitHub already has `polish_features.py`, `tests/test_polish_features.py`, `vto_client.py`, `tests/test_vto_client.py`, profile persistence in `storage.py`, and the newer main application flow for bilingual UI, camera capture, local profile/reminder preferences, and PDF report use. Those should **not** be described as new from this archive without a deeper file-by-file diff.

## Features in the uploaded v2 snapshot that are absent from the current GitHub tree by filename/module
These modules/files do not appear in the GitHub `main` tree inspected:

1. `auth.py` — username/password registration and authentication, password hashing, login throttling/lockout, user identity helpers.
2. `cart.py` — per-user cart, quantity/total handling, order records, shopping-list export, optional Razorpay test-mode payment links/status checks.
3. `derm.py` — urgent-symptom screening helper, clinician-facing summary, consultation request payload, mailto draft link.
4. `progress.py` — scan-derived progress summary paired with routine adherence.
5. `revision.py` — adaptive routine-revision engine with saved, reviewable/revertible revision operations.
6. `ui_extra.py` — Streamlit integration surfaces for accounts, cart/orders, VTO, clinician hand-off, routine revisions, progress and connection checks.
7. `vto.py` — validated makeup-effect payload builder for YouCam VTO.
8. `scripts/verify_youcam.py`, `scripts/verify_llm.py`, `scripts/verify_catalogue.py` — manual live-configuration/response/catalogue verification helpers.
9. `Dockerfile`, `docker-compose.yml`, `render.yaml`, `.dockerignore` — container/deployment setup.
10. `tests/test_accounts_isolation.py`, `tests/test_app_flow.py`, `tests/test_cart.py`, `tests/test_catalogue.py`, `tests/test_consult_vto_progress.py`, `tests/test_image_prepare.py`, `tests/test_parse_scores.py`, `tests/test_revision.py`, `tests/test_youcam_flow.py` — expanded coverage for these flows.
11. `DEMO_SCRIPT.md`, `DEVPOST_SUBMISSION.md`, `CHANGELOG.md` — demonstration/submission documentation.

These are new by file/path relative to the currently inspected GitHub tree. Their feature claims are based on the archive's source code and test names, not proof that the live external YouCam/Razorpay/LLM services work with your credentials.

## Existing or overlapping areas — do not copy from the archive as standalone “new” code
- `app.py`: **overlaps heavily** with the existing GitHub application and must not simply replace it as a standalone feature file.
- `storage.py`: GitHub already stores profiles and supports scans, routines, journal/check-ins; the v2 version expands the schema for accounts/carts/orders/consults/revisions and includes migrations. Integrate its schema changes carefully rather than treating the entire file as wholly new.
- `differentiators.py`: GitHub already has this module and many matching helpers (scan comparison, routine adaptation notes, ingredient-conflict checking, budget optimisation, LLM coach, cheaper swaps). The v2 version may differ in logic; only the specific changed functions should be merged after a diff.
- `image_quality.py`: GitHub already has this; v2 expands it with EXIF correction and image preparation. Merge only the missing functions/constants and related call sites.
- `products.py`: GitHub already has the catalogue and recommendation/filtering. v2 expands it with retailer links/catalogue overrides/verification helpers. Merge selectively.
- `skincare.py`: GitHub already has the routine builder and coach. v2 changes score parsing and interpretation; merge selective parser/routine changes rather than replacing the whole module blindly.
- `youcam_client.py`: GitHub already has a client, but v2 adds/changes documented File API upload, ZIP score parsing, async task handling and VTO-related integration. Diff functions before merging.
- `requirements.txt`, `.env.example`, `.gitignore`, tests, and README already exist on GitHub. Update only for verified additions; do not overwrite indiscriminately.

## Integration dependencies
The unique modules in the archive depend on one another. They are not each independently runnable:
- `auth.py` requires `storage.connect` and account tables/columns.
- `cart.py` requires `storage.connect`, `storage.GUEST`, and `products` helpers (`PRODUCTS`, `get_product`, `retailer_name`), plus `requests` for optional payment-link API calls.
- `derm.py` is mostly standard library (`typing`, `urllib.parse`) but its clinician hand-off UI is wired in `ui_extra.py`/`app.py` and uses saved consultation data from `storage.py`.
- `progress.py` depends on `differentiators.NOISE_BAND` and `compare_scans`.
- `revision.py` depends on `differentiators.NOISE_BAND` and `compare_scans`, plus revision persistence in `storage.py`.
- `ui_extra.py` depends on `auth.py`, `cart.py`, `derm.py`, `vto.py`, `image_quality.py`, `products.py`, `progress.py`, `revision.py`, `storage.py`, and `youcam_client.py`.
- `vto.py` is used by `ui_extra.py` and the verification script.
- Verification scripts depend on the corresponding app modules and `.env` variables.
- Runtime requirements in the archive are Streamlit, requests, python-dotenv, pytest, and Pillow. PDF generation already present on GitHub's `polish_features.py` requires `reportlab`, which is not listed in the archive's current `requirements.txt`; add it if the PDF feature is used in a clean environment.

## Recommended integration order
1. Back up your working tree and create a separate Git branch locally.
2. Merge/update `storage.py` schema and migration logic first, preserving the GitHub profile APIs and data.
3. Add `auth.py`; wire `ui_extra.init_identity()` and `account_sidebar()` only after storage migration tests pass.
4. Merge the distinct product/checkout helpers needed by `cart.py`, then add `cart.py`.
5. Add `derm.py`, `progress.py`, `revision.py`, and `vto.py`; run their tests.
6. Add `ui_extra.py` and port only new UI tabs/panels into the existing `app.py`, not a wholesale replacement.
7. Merge only verified deltas to `image_quality.py`, `skincare.py`, `differentiators.py`, and `youcam_client.py` after a real diff.
8. Add deployment/verification files if you intend to use those platforms.
9. Run `python -m pytest -q` and the relevant live smoke tests. API and payment functions must be tested with private credentials; use Razorpay test keys only.

## Verification limitation
A path-level comparison was performed against the GitHub tree. The unique modules and tests above are absent by filename in that tree. A complete semantic/function-by-function diff of every same-named file and a full test run of the entire snapshot were not completed here. Do not assume the v2 snapshot runs correctly in production from this report alone.
