"""Streamlit UI for the newer SkinWise features. Business logic lives in the plain modules; this is presentation only."""
from __future__ import annotations

import json
import os
from datetime import date
from uuid import uuid4

import requests
import streamlit as st

import auth
import cart as cartlib
import derm
import vto as vtolib
from image_quality import VTO_MAX_LONG_SIDE, inspect_image, prepare_image
from products import catalogue_status, get_product, retailer_links
from progress import progress_report, report_text
from revision import active_ops
from storage import (GUEST, delete_account, get_consult_requests, get_revisions, save_consult_request, set_revision_status)
from youcam_client import DEFAULT_BASE_URL, YouCamError, check_connection, run_makeup_vto


def _key_and_base() -> tuple[str, str]:
    return os.getenv("YOUCAM_API_KEY", "").strip(), os.getenv("YOUCAM_API_BASE_URL", DEFAULT_BASE_URL).strip()


# --------------------------------------------------------------------------- identity
def init_identity() -> str:
    if "user_id" not in st.session_state:
        single_user = os.getenv("SKINWISE_SINGLE_USER", "").strip() == "1"
        st.session_state.user_id = GUEST if single_user else f"guest-{uuid4().hex[:12]}"
        st.session_state.username = None
    return st.session_state.user_id


def _reset_session_data() -> None:
    for key, default in {"analysis": None, "source": None, "history": [], "completed_steps": [], "scans": [],
                         "routine_notes": "", "coach_messages": [], "journal_loaded": False, "vto_result": None,
                         "payment_link": None}.items():
        st.session_state[key] = default


def account_sidebar() -> str:
    uid = init_identity()
    with st.sidebar:
        st.header("Account")
        if st.session_state.username:
            st.success(f"Signed in as **{st.session_state.username}**")
            st.caption("Your scans, routines, cart and journal are saved to your account on this server.")
            c1, c2 = st.columns(2)
            if c1.button("Sign out", width="stretch"):
                st.session_state.user_id = f"guest-{uuid4().hex[:12]}"
                st.session_state.username = None
                _reset_session_data()
                st.rerun()
            with c2.popover("Delete account", width="stretch"):
                st.warning("Permanently deletes your login and all saved data.")
                if st.button("Yes, delete everything", key="confirm_delete_account"):
                    delete_account(st.session_state.username)
                    st.session_state.user_id = f"guest-{uuid4().hex[:12]}"
                    st.session_state.username = None
                    _reset_session_data()
                    st.rerun()
        else:
            if uid == GUEST:
                st.caption("Single-user local mode: data is stored without an account.")
            else:
                st.caption("Guest session: data lasts only for this browser session. Create an account to keep scans and progress across visits.")
                mode = st.radio("Account", ["Sign in", "Create account"], horizontal=True, label_visibility="collapsed")
                with st.form("account_form", clear_on_submit=False):
                    name = st.text_input("Username")
                    pw = st.text_input("Password", type="password", help="At least 8 characters. Don't reuse an important password in a prototype.")
                    submitted = st.form_submit_button(mode)
                if submitted:
                    try:
                        new_uid = auth.register(name, pw) if mode == "Create account" else auth.authenticate(name, pw)
                        st.session_state.user_id = new_uid
                        st.session_state.username = auth.normalize_username(name)
                        _reset_session_data()
                        st.rerun()
                    except auth.AuthError as exc:
                        st.error(str(exc))
        st.divider()
    return st.session_state.user_id


# --------------------------------------------------------------------------- cart
def add_to_cart_button(product: dict, uid: str, context: str) -> None:
    if st.button("Add to cart", key=f"add_{context}_{product['id']}"):
        cartlib.add_to_cart(product["id"], 1, user_id=uid)
        st.toast(f"Added {product['name']}")


def render_cart_tab(uid: str) -> None:
    st.subheader("07 · Cart & orders")
    st.info("SkinWise doesn't sell or ship products. Your cart becomes an **order record and a per-retailer shopping list** with links, so you can buy from the retailer you prefer. Prices are indicative catalogue snapshots.")
    items = cartlib.get_cart(user_id=uid)
    status = catalogue_status()
    if status["verified"] < status["total"]:
        st.caption(f"{status['unverified']} of {status['total']} catalogue prices have not been verified (see README: catalogue verification).")
    if not items:
        st.caption("Your cart is empty. Add products from the Product match tab.")
    else:
        for item in items:
            p = item["product"]
            with st.container(border=True):
                c1, c2, c3, c4 = st.columns([4, 1.3, 1.2, 1])
                c1.markdown(f"**{p['name']}**")
                c1.caption(f"{p['category'].title()} · ₹{p['price_inr']} each" + ("" if p.get("verified_on") else " · price unverified"))
                qty = c2.number_input("Qty", 1, cartlib.MAX_QTY, item["qty"], key=f"qty_{p['id']}", label_visibility="collapsed")
                if qty != item["qty"]:
                    cartlib.set_quantity(p["id"], int(qty), user_id=uid); st.rerun()
                c3.write(f"₹{p['price_inr'] * int(qty)}")
                if c4.button("Remove", key=f"rm_{p['id']}"):
                    cartlib.set_quantity(p["id"], 0, user_id=uid); st.rerun()
        summary = cartlib.cart_summary(items)
        st.metric("Indicative subtotal", f"₹{summary['subtotal_inr']}", f"{summary['count']} item(s)")
        st.markdown("**Buy from a retailer**")
        for retailer, rows in summary["by_retailer"].items():
            for row in rows:
                cols = st.columns([3, 1, 1, 1])
                cols[0].write(row["product"]["name"])
                for col, link in zip(cols[1:], retailer_links(row["product"])):
                    col.markdown(f"[{link['retailer']}]({link['url']})")
        note = st.text_input("Order note (optional)", max_chars=200)
        if st.button("Create order record", type="primary"):
            order = cartlib.place_order(user_id=uid, note=note)
            st.session_state.last_order_id = order["id"]
            st.success(f"Order #{order['id']} saved. No payment has been taken.")
            st.rerun()
    # Latest order: shopping list + optional payment
    orders = cartlib.list_orders(user_id=uid)
    if orders:
        order = next((o for o in orders if o["id"] == st.session_state.get("last_order_id")), orders[0])
        st.markdown(f"### Order #{order['id']} · {order['status']} · ₹{order['total_inr']}")
        text = cartlib.order_shopping_list(order)
        st.download_button("Download shopping list (.txt)", text, f"skinwise-order-{order['id']}.txt", "text/plain")
        if cartlib.payments_configured():
            mode = cartlib.payments_mode()
            if mode == "live":
                st.error("LIVE Razorpay keys detected. SkinWise doesn't fulfil these products, so don't collect real payments with it. Use rzp_test_ keys.")
            else:
                st.caption("Razorpay **test mode** payment link (demo only, no real money). Use Razorpay's test card/UPI details.")
                key_id, secret = os.getenv("RAZORPAY_KEY_ID", ""), os.getenv("RAZORPAY_KEY_SECRET", "")
                if mode == "test" and st.button("Create test payment link"):
                    try:
                        link = cartlib.create_payment_link(order, key_id, secret, os.getenv("PUBLIC_APP_URL"))
                        cartlib.update_order(order["id"], "payment_pending", link["id"], user_id=uid)
                        st.session_state.payment_link = link
                        st.rerun()
                    except cartlib.CartError as exc:
                        st.error(str(exc))
                if order.get("payment_link_id"):
                    link = st.session_state.get("payment_link")
                    if link and link["id"] == order["payment_link_id"]:
                        st.markdown(f"[Open test payment page]({link['short_url']})")
                    if st.button("Check payment status"):
                        try:
                            rz = cartlib.fetch_payment_link_status(order["payment_link_id"], key_id, secret)
                            if rz in cartlib.RAZORPAY_TO_ORDER_STATUS:
                                cartlib.update_order(order["id"], cartlib.RAZORPAY_TO_ORDER_STATUS[rz], user_id=uid)
                            st.info(f"Razorpay status: {rz}"); st.rerun()
                        except cartlib.CartError as exc:
                            st.error(str(exc))
        else:
            st.caption("Payments are off. To demo checkout, set RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET to **test-mode** keys.")
        if len(orders) > 1:
            with st.expander("Earlier orders"):
                st.dataframe([{"order": o["id"], "status": o["status"], "total_inr": o["total_inr"], "created": o["created_at"]} for o in orders],
                             width="stretch", hide_index=True)


# --------------------------------------------------------------------------- try-on
def render_vto_tab(uid: str) -> None:
    st.subheader("08 · Look preview (YouCam AI Makeup Virtual Try-On)")
    st.write("Try a makeup look on your own photo after you've built your routine. This previews **makeup only**; it does not predict how your skin will change.")
    photo = st.file_uploader("Upload a front-facing JPG or PNG", type=["jpg", "jpeg", "png"], key="vto_photo")
    c1, c2 = st.columns(2)
    look = c1.selectbox("Look", list(vtolib.LOOKS))
    finish = c2.radio("Lip finish", ["matte", "gloss"], horizontal=True)
    spec = vtolib.LOOKS[look]
    lip = c1.color_picker("Lip colour", spec["lip"], key=f"lip_{look}")
    intensity = c2.slider("Lip intensity", 0, 100, spec["lip_intensity"], key=f"int_{look}")
    blush = st.checkbox("Include blush", value=True)
    st.info("Photo privacy: the selected photo is sent to YouCam to render the preview (1 API unit). SkinWise doesn't store the photo or the rendered image.")
    consent = st.checkbox("I consent to sending this photo to YouCam for the try-on.", key="vto_consent")
    if st.button("Render look with YouCam", type="primary", disabled=not (photo and consent)):
        key, base = _key_and_base()
        if not key:
            st.error("Live API is not configured. Add YOUCAM_API_KEY.")
        else:
            try:
                data, ctype = prepare_image(photo.getvalue(), max_long_side=VTO_MAX_LONG_SIDE)
                effects = vtolib.build_effects(look, lip, intensity, include_blush=blush, lip_finish=finish)
                with st.spinner("Rendering your look…"):
                    out = run_makeup_vto(key, data, "selfie.jpg", ctype, effects, base_url=base)
                st.session_state.vto_result = {"before": data, "after": out["image_bytes"], "look": look}
            except ValueError as exc:
                st.error(str(exc))
            except requests.exceptions.RequestException:
                st.error("Could not reach YouCam. Check your network and API host, then retry.")
            except YouCamError as exc:
                st.error(str(exc))
    result = st.session_state.get("vto_result")
    if result:
        b, a = st.columns(2)
        b.image(result["before"], caption="Your photo", width="stretch")
        a.image(result["after"], caption=f"{result['look']} (virtual try-on)", width="stretch")
        st.download_button("Download preview", result["after"], "skinwise-look.jpg", "image/jpeg")
        st.caption("Rendered by YouCam AI Makeup Virtual Try-On. Real product colours and finishes vary.")


# --------------------------------------------------------------------------- consult
def render_consult_tab(uid: str, profile: dict, plan: dict | None, scans: list[dict], journal: list[dict]) -> None:
    st.subheader("09 · See a dermatologist")
    st.warning("SkinWise **cannot book appointments or run live consultations**. It helps you prepare: screen for urgent symptoms, build a summary to hand to a clinician, save a request, and find established teleconsultation services.")
    flags = st.multiselect("Do any of these apply right now?", list(derm.URGENT_FLAGS), key="urgent_flags")
    screen = derm.urgent_screen(flags)
    if screen["urgent"]:
        st.error(screen["message"])
        return
    c1, c2 = st.columns(2)
    reason = c1.selectbox("Reason for the visit", derm.REASONS)
    mode = c2.radio("Preferred type", ["In-person", "Teleconsultation"], horizontal=True)
    city = c1.text_input("City / area", max_chars=80)
    timing = c2.text_input("Preferred days / times", max_chars=120, placeholder="e.g. weekday evenings")
    note = st.text_area("Anything the clinician should know (symptoms, new products, allergies)", max_chars=1000)
    revisions = get_revisions(user_id=uid)
    summary = derm.build_clinician_summary(profile, scans, plan, journal, revisions, reason=reason, patient_note=note)
    with st.expander("Preview the summary you can share", expanded=True):
        st.text(summary)
    st.download_button("Download summary (.txt)", summary, "skinwise-clinician-summary.txt", "text/plain")
    clinic = st.text_input("Clinic email (optional)", placeholder="clinic@example.com")
    request = derm.build_consult_request(mode=mode, city=city, reason=reason, timing=timing, contact_note=note[:300], summary_included=True)
    if clinic and "@" in clinic:
        st.markdown(f"[Open an email draft to {clinic}]({derm.mailto_link(clinic, request, summary)})")
        st.caption("The draft contains your health summary. Check it before sending.")
    if st.button("Save this request"):
        save_consult_request(request, user_id=uid)
        st.success("Saved in your account. Nothing was sent anywhere.")
    st.markdown("**Find a clinician**")
    for d in derm.TELECONSULT_DIRECTORIES:
        st.markdown(f"- [{d['name']}]({d['url']})")
    st.caption(derm.DIRECTORY_NOTE)
    saved = get_consult_requests(user_id=uid)
    if saved:
        with st.expander("Saved requests"):
            st.dataframe([{k: v for k, v in r.items() if k != "summary_included"} for r in saved], width="stretch", hide_index=True)


# --------------------------------------------------------------------------- revisions & progress
def render_revision_panel(uid: str) -> None:
    st.markdown("### Adaptive routine (automatic revisions)")
    revisions = get_revisions(user_id=uid)
    if not revisions:
        st.caption("After your second real scan, SkinWise compares it with the previous one and automatically revises your routine. Revisions only simplify or soften the routine, never add actives, and you can revert any of them.")
        return
    latest = revisions[0]
    badge = {"applied": "✅ applied", "reverted": "↩️ reverted"}[latest["status"]]
    st.markdown(f"**Latest revision** ({latest.get('to_date', '')}) · {badge}")
    if latest.get("outcome") == "unchanged":
        st.success("No tracked metric dropped beyond the photo-noise band. Your routine was left as is.")
    for change in latest.get("changes", []):
        st.write(f"- **{change['metric']}** ({change['delta']:+g}): {change['action']}. _{change['reason']}_")
    for kept in latest.get("kept", []):
        st.write(f"- 👍 {kept}")
    if latest.get("escalate"):
        st.error("Scores fell sharply. Consider seeing a dermatologist; see the Dermatologist tab for a summary you can bring.")
    st.caption(latest.get("disclaimer", ""))
    if latest.get("ops"):
        if latest["status"] == "applied":
            if st.button("Revert this revision"):
                set_revision_status(latest["id"], "reverted", user_id=uid); st.rerun()
        elif st.button("Re-apply this revision"):
            set_revision_status(latest["id"], "applied", user_id=uid); st.rerun()
    if len(revisions) > 1:
        with st.expander("Revision history"):
            st.dataframe([{"scan date": r.get("to_date"), "outcome": r.get("outcome"), "status": r["status"],
                           "changes": "; ".join(c["action"] for c in r.get("changes", []))} for r in revisions], width="stretch", hide_index=True)


def render_progress(live_scans: list[dict], checkins: list[dict]) -> None:
    rep = progress_report(live_scans, checkins)
    st.markdown("### Measured progress report")
    if not rep["available"]:
        st.caption(rep["reason"]); return
    c1, c2, c3 = st.columns(3)
    if rep["overall"]:
        o = rep["overall"]
        c1.metric("Overall score", f"{o['followup']:g}", f"{o['delta']:+g} since {rep['from_date']}")
    c2.metric("Metrics improved / declined", f"{len(rep['improved'])} / {len(rep['declined'])}", f"{len(rep['steady'])} within noise", delta_color="off")
    a = rep["adherence"]
    c3.metric("Routine completion", f"{a['avg_completion_pct']}%" if a["avg_completion_pct"] is not None else "n/a", f"{a['days_logged']} day(s) logged", delta_color="off")
    for note in rep["notes"]:
        st.caption("• " + note)
    st.download_button("Download progress report (.txt)", report_text(rep), "skinwise-progress.txt", "text/plain")


def connection_check_ui() -> None:
    st.markdown("### Test the YouCam connection")
    if st.button("Run connection check"):
        key, base = _key_and_base()
        try:
            info = check_connection(key, base)
            st.success(f"Connected to {info['host']}. Your key was accepted and the File API issued an upload slot. No analysis was started.")
        except YouCamError as exc:
            st.error(f"{exc} (category: {exc.category})")
        except requests.exceptions.RequestException:
            st.error("Could not reach the YouCam host. Check network access and YOUCAM_API_BASE_URL.")
        st.caption("A real scan is still the only full test. Verify unit usage in your YouCam API Console.")
